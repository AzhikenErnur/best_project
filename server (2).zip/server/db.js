const users = [
    { id: 1, email: "bolat@gmail.com", password: "bol123", username: "Bolat" },
    { id: 2, email: "didar@gmail.com", password: "did123", username: "Didar" },
    { id: 3, email: "eldar@gmail.com", password: "el123", username: "Eldar" },
];

const categories = [
    { id: 1, name: "IT" },
    { id: 2, name: "Engineering" },
    { id: 3, name: "Medical" },
];

const goods = [
    { id: 1, namel: "ASUS", price: 457000, categoryId: 1, userId: 2 },
    { id: 2, namel: "Lenovo", price: 230000, categoryId: 3, userId: 1 },
    { id: 3, namel: "HP", price: 340000, categoryId: 3, userId: 3 }
];

const students = [
    { id: 1, name: "John Doe", age: 25, categoryId: 1 },
    { id: 2, name: "Alice Smith", age: 23, categoryId: 2 },
    { id: 3, name: "Bob Brown", age: 27, categoryId: 3 }
];

const specialities = [
    { id: 1, name: "Software Engineering" },
    { id: 2, name: "Electrical Engineering" },
    { id: 3, name: "Nursing" }
];

module.exports = { users, categories, goods, students, specialities };
