const express = require('express');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');
const cors = require('cors');

const users = [
    { id: 2, email: "ernur@gmail.com", password: "e123", username: "Ernur", isAdmin: true },
    { id: 3, email: "sanik@gmail.com", password: "sonik123", username: "Sorpa", isAdmin: false }
];

const categories = [
    { id: 1, name: "КРУПНАЯ БЫТОВАЯ ТЕХНИКА" },
    { id: 2, name: "КОМПЬЮТЕРНАЯ ТЕХНИКА" },
    { id: 3, name: "ТЕЛЕВИЗОРЫ" },
    { id: 4, name: "КЛИМАТИЧЕСКАЯ ТЕХНИКА" },
];

const posts = [
    { id: 1, title: "Холодильник Haier MSR115", price: 500000, content: "Механический термостат,Стандартный компрессор,Класс А+,83,2/47,5/44,2 см,Гарантия 5 лет", tegi: "Холодильники", platform: "Артур Конан Дойл", userId: 1, categoryId: 1, url:"https://haieronline.kz/catalog/appliances/fridges/kholodilnik-haier-msr115/" },
    { id: 2, title: "Морозильный ларь Haier HCE100R", price: 140000, content: "Разморозка Static, Класс А+,Замораживание: 9 кг/сут, Объем 98 л, Гарантия 5 лет", tegi: "Морозильные камеры", platform: "Джейн Остин", userId: 1, categoryId: 1, url:"" },
    { id: 3, title: "СТИРАЛЬНАЯ МАШИНА HAIER HW60-BP12919B", price: 160000, content: "Загрузка 6 кг, Программа освежения паром, Скорость отжима 1200 об/мин, Инверторный мотор, Гарантия 5 лет", tegi: "Стиральные машины", platform: "Герман Мелвилл", userId: 1, categoryId: 1, url:""},
    { id: 4, title: "ТЕЛЕВИЗОР HAIER 32 SMART TV S1", price: 450000, content: "Диагональ 32, Full HD, Android TV,  DBX-TVб, HDR10", tegi: "Все телевизоры", platform: "Харпер Ли", userId: 2, categoryId: 3, url:"" },
    { id: 5, title: "Телевизор Haier 55 OLED S9 Ultra", price: 55000, content: "Диагональ 55, OLED, Google TV, Harman Kardon", tegi: "OLED", platform: "Брэм Стокер", userId: 2, categoryId: 3 , url:""},
    { id: 6, title: "Игровой компьютер Thunderobot Alpha D", price: 500000, content: "Процессор i5-12400, Видеокарта GTX 1650 4GB, 16 GB RAM 512 GB SSD, Без ОС", tegi: "Игровые компьютеры", platform: "Джордж Оруэлл", userId: 2, categoryId: 2, url:"" },
    { id: 7, title: "Игровой ноутбук Thunderobot 911S Core SD", price: 40000, content: "Экран 15.6, Full HD 144 ГЦ IPS, Видеокарта: RTX 3050 4GB, 8 GB RAM 512 GB SSD, Без ОС", tegi: "Игровые ноутбуки", platform: "ИДжордж Оруэлл", userId: 3, categoryId: 2, url:"" },
    { id: 8, title: "Франкенштейн", price: 450000, content: "Площадь помещения: до 20 м², Компрессор: Инверторный, Самоочистка кондиционера, Мин. температура в режиме обогрева: -15°С", tegi: "Кондиционеры", platform: "Мэри Шелли", userId: 3, categoryId: 4, url:"" },
    { id: 9, title: "Холодильник LG GA-B489YLCZ", price: 450000, content: "Системы охлаждения No Frost, Инверторный компрессор, Класс A++, 176 см, Гарантия 2 года", tegi: "Холодильники", platform: "Гарри Поттер", userId: 1, categoryId: 1, url:"https://lg.com/catalog/appliances/refrigerators/lg-ga-b489ylcz/" },
    { id: 10, title: "Плита газовая Gefest 3200", price: 70000, content: "4 газовые конфорки, Электрический духовка, Таймер, Габариты: 85x50x60 см, Гарантия 1 год", tegi: "Плиты", platform: "Артур Конан Дойл", userId: 1, categoryId: 1, url:"https://gefest.by/catalog/stoves/gefest-3200/" },
    { id: 11, title: "Кофемашина DeLonghi ECAM 22.110.B", price: 95000, content: "Капучинатор, Диспенсер для молока, Автоматическая очистка, 13 программ для кофе, Гарантия 2 года", tegi: "Кофемашины", platform: "Харпер Ли", userId: 2, categoryId: 1, url:"https://delonghi.com/catalog/coffee-machines/ecam-22-110-b/" },
    { id: 12, title: "Микроволновая печь Samsung MS23F301EAS", price: 30000, content: "Гриль, Автоматическое размораживание, 23 л, Элементы управления сенсорные, Гарантия 1 год", tegi: "Микроволновки", platform: "Брэм Стокер", userId: 2, categoryId: 1, url:"https://samsung.com/catalog/microwave-oven/ms23f301eas/" },
    { id: 13, title: "Смартфон Samsung Galaxy S23 Ultra", price: 850000, content: "Процессор Exynos 2200, 12 GB RAM, 256 GB ROM, Камера 200 MP, Гарантия 1 год", tegi: "Смартфоны", platform: "Фрэнк Герберт", userId: 2, categoryId: 2, url:"https://samsung.com/catalog/smartphones/galaxy-s23-ultra/" },
    { id: 14, title: "Ноутбук Apple MacBook Pro 16\" M2", price: 220000, content: "Процессор M2 Pro, 16 GB RAM, 1 TB SSD, Retina Display, Гарантия 1 год", tegi: "Ноутбуки", platform: "Джордж Оруэлл", userId: 3, categoryId: 2, url:"https://apple.com/catalog/notebooks/macbook-pro-16-m2/" },
    { id: 15, title: "Смарт-часы Apple Watch Series 8", price: 50000, content: "GPS, Мониторинг сердечного ритма, Круглосуточный трекер активности, Гарантия 1 год", tegi: "Смарт-часы", platform: "Айзек Азимов", userId: 3, categoryId: 2, url:"https://apple.com/catalog/smartwatches/apple-watch-series-8/" },
    { id: 16, title: "Проектор Epson EH-TW7100", price: 120000, content: "4K, HDR, Яркость 3000 Лм, Соотношение сторон 16:9, Гарантия 2 года", tegi: "Проекторы", platform: "Стивен Кинг", userId: 3, categoryId: 3, url:"https://epson.com/catalog/projectors/eh-tw7100/" },
    { id: 17, title: "Колонка JBL Charge 5", price: 25000, content: "Bluetooth, Время работы до 20 часов, Водонепроницаемая, Поддержка зарядки USB-C", tegi: "Акустика", platform: "Рэй Брэдбери", userId: 3, categoryId: 2, url:"https://jbl.com/catalog/speakers/charge-5/" },
    { id: 18, title: "Вакуумный упаковщик FoodSaver VS3180", price: 45000, content: "Автоматическая подача пакетов, Встроенный резак, Компактные размеры, Гарантия 1 год", tegi: "Кухонные приборы", platform: "Джон Гришэм", userId: 1, categoryId: 1, url:"https://food-saver.com/catalog/vacuum-sealers/vs3180/" },

];

const app = express();
const secretKey = 'token';

app.use(cors());
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.post('/register', (req, res) => {
    const { email, password, username } = req.body;
    const existingUser = users.find(user => user.email === email);
    if (existingUser) {
        return res.status(400).json({ message: "User with this email already exists" });
    }
    const newUser = { id: users.length + 1, email, password, username, isAdmin: false };
    users.push(newUser);
    res.json({ message: `User ${username} was registered...` });
});

app.get('/categories', (req, res) => {
    res.json(categories);
});

app.get('/users', (req, res) => {
    res.json(users);
});

app.post('/login', (req, res) => {
    const { email, password } = req.body;
    const user = users.find(user => user.email === email && user.password === password);
    if (user) {
        const token = jwt.sign({ userId: user.id, isAdmin: user.isAdmin }, secretKey, { expiresIn: '1h' });
        res.json({ userId: user.id, username: user.username, isAdmin: user.isAdmin, token });
    } else {
        res.status(401).json({ message: "Wrong username or password..." });
    }
});

const checkToken = (req, res, next) => {
    const authValue = req.headers['authorization'];
    if (!authValue) {
        return res.status(401).json({ message: "Token not found..." });
    }
    const token = authValue.split(' ')[1];
    jwt.verify(token, secretKey, (err, value) => {
        if (err) {
            return res.status(401).json({ message: "Invalid Token..." });
        }
        req.userId = value.userId;
        req.isAdmin = value.isAdmin;
        next();
    });
};

const checkAdmin = (req, res, next) => {
    if (!req.isAdmin) {
        return res.status(403).json({ message: "Access forbidden: Admins only" });
    }
    next();
};

app.get('/privatePosts', checkToken, (req, res) => {
    const postsToSend = posts.filter(p => p.userId === req.userId);
    res.json(postsToSend);
});

app.get('/posts', (req, res) => {
    res.json(posts);
});

app.post('/posts/create', checkToken, (req, res) => {
    const { title, content, categoryId } = req.body;
    const newPost = { id: posts.length + 1, title, content, userId: req.userId, categoryId };
    posts.push(newPost);
    res.json({ message: `Post ${title} was created...` });
});

app.post('/categories/create', checkToken, checkAdmin, (req, res) => {
    const { name } = req.body;
    const newCategory = { id: categories.length + 1, name };
    categories.push(newCategory);
    res.json({ message: `Category ${name} created successfully...` });
});


app.get('/posts/category/:categoryId', (req, res) => {
    const postsToSend = posts.filter(p => p.categoryId == req.params.categoryId);
    res.json(postsToSend);
});

app.put('/categories/:categoryId', checkToken, (req, res) => {
    const categoryIndex = categories.findIndex(c => c.id == req.params.categoryId);
    if (categoryIndex !== -1) {
        categories[categoryIndex].name = req.body.name;
        res.json({ message: "Category updated successfully..." });
    } else {
        res.status(404).json({ message: "Category not found..." });
    }
});

app.delete('/posts/:postId', checkToken, (req, res) => {
    const postIndex = posts.findIndex(p => p.id == req.params.postId);
    if (postIndex !== -1) {
        const post = posts[postIndex];
        if (req.userId === post.userId || req.isAdmin) {
            posts.splice(postIndex, 1);
            res.json({ message: "Post deleted successfully..." });
        } else {
            res.status(403).json({ message: "Access forbidden: Only the creator or an admin can delete this post" });
        }
    } else {
        res.status(404).json({ message: "Post not found..." });
    }
});

app.delete('/categories/:categoryId', checkToken, checkAdmin, (req, res) => {
    const categoryIndex = categories.findIndex(c => c.id == req.params.categoryId);
    if (categoryIndex !== -1) {
        categories.splice(categoryIndex, 1);
        res.json({ message: "Category deleted successfully..." });
    } else {
        res.status(404).json({ message: "Category not found..." });
    }
});

app.get('/posts/:postId', (req, res) => {
    console.log("GET /posts/:postId requested");
    const postId = req.params.postId;
    const foundPost = posts.find(p => p.id == postId);
    if (foundPost) {
        res.json(foundPost);
    } else {
        res.status(404).json({ message: `Post with id=${postId} not found` });
    }
});

app.put('/posts/:postId', (checkToken || checkAdmin), (req, res) => {
    console.log("PUT /posts/:postId requested");
    const userId = req.userId;
    const postId = req.params.postId;
    const { title, content, categoryId } = req.body;
    const postIndex = posts.findIndex(p => p.id == postId);
    if (postIndex != -1) {
        posts[postIndex] = { id: postId, title, content, categoryId, userId };
        res.json({ message: `Post ${title} was edited...` });
    } else {
        res.status(404).json({ error: 'Post is not found' });
    }
});

app.listen(3005, () => {
    console.log('Server started on port ...');
});
